import React from 'react'
import Navbar from "../components/Navbar"
import SelectDropdown from '../components/SelectDropdown'
export default function Schemes() {
  return (
    <>
    <Navbar />
    <SelectDropdown />
    </>
  )
}
