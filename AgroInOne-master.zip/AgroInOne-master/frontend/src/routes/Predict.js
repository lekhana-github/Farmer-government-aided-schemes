import React from 'react'
import NavBar from '../components/Navbar'
import Predictcard from '../components/predict/Predictcard'

export default function Predict() {
  return (
    <>
    <NavBar/>
    <br/>
    <Predictcard/>
    </>
  )
}
