import React from 'react'
import NavBar from '../components/Navbar'
import PredictLoan from '../components/predict/PredictLoan'

export default function Predictloan() {
  return (
    <>
    <NavBar/>
    <br/>
    <PredictLoan/>
    </>
  )
}
