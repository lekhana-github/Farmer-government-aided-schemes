import React from 'react';
import NavBar from '../components/Navbar'
import Predictcrop from '../components/predict/Predictcrop';


export default function PredictCrop() {
  return (
    <>
    <NavBar/>
    <br/>
    <Predictcrop/>
    </>
  )
}
